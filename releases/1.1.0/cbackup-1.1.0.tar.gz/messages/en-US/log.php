<?php
/** @noinspection HtmlUnknownTarget */
$lang = array(
    'Action' => 'Action',
    'All actions' => 'All actions',
    'All levels' => 'All levels',
    'All users' => 'All users',
    'Date/time from' => 'Date/time from',
    'Date/time to' => 'Date/time to',
    'Enter node name' => 'Enter node name',
    'Mailer logs' => 'Mailer logs',
    'No logs found in database' => 'No logs found in database',
    'Node logs' => 'Node logs',
    'Node name' => 'Node name',
    'Pick date/time' => 'Pick date/time',
    'Scheduler logs' => 'Scheduler logs',
    'Severity' => 'Severity',
    'Show full message' => 'Show full message',
    'System logs' => 'System logs',
    'Task name' => 'Task name',
    'View all nodes\' logs' => 'View all nodes\' logs',
    'View all scheduler logs' => 'View all scheduler logs',
    'View all system logs' => 'View all system logs',
);

return $lang;
